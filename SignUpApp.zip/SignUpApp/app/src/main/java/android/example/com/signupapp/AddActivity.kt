package android.example.com.signupapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast

class AddActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)

        val btnSave = findViewById<ImageButton>(R.id.btnSave)
        btnSave.setOnClickListener() {
            val username = findViewById<EditText>(R.id.inputName)
            val password = findViewById<EditText>(R.id.inputPassword)
        }
    }
}