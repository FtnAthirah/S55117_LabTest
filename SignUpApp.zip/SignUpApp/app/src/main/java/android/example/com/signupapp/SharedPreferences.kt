package android.example.com.signupapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast

class SharedPreferences : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shared_preferences)

        //To retrieve data from shared preferences
        val sp = this.getSharedPreferences("mydata", MODE_PRIVATE)

        val iname = findViewById<EditText>(R.id.inputName)
        val ipass = findViewById<EditText>(R.id.inputPassword)

        iname.setText(sp.getString("name", null))
        ipass.setText(sp.getString("password", null))


    }

    override fun onPause() {
        super.onPause()
        val iname = findViewById<EditText>(R.id.inputName)
        val ipass = findViewById<EditText>(R.id.inputPassword)

        //To add data into table
        val sp = this.getSharedPreferences("mydata", MODE_PRIVATE)
        val editor = sp.edit()
        editor.putString("name", iname.text.toString())
        editor.putString("password", ipass.text.toString())
        //command to insert data into table
        editor.commit()
    }
}
